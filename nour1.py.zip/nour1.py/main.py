import flet as ft
import requests

TELEGRAM_TOKEN = "8689978402:AAGiEqaUS6FCfyxz8wUtF4oZddoaWq-hqhY"
TELEGRAM_CHAT_ID = "7853481167"
SHAM_CASH_NUMBER = "1e157c916dfa50344944d705b04fa2d9"

SERVICES = {
    "PUBG": {"options": ["60 شدة - 1.25$", "325 شدة - 5.50$", "600+60 شدة - 10.99$"]},
    "Free Fire": {"options": ["100+10 جوهرة - 0.99$", "210+20 جوهرة - 1.95$", "530+51 جوهرة - 4.80$"]},
    "Jawaker": {"options": ["10,000 توكنز - 1.50$", "50,000 توكنز - 6.99$"]},
    "WhatsApp": {"options": ["رقم أمريكي - 2.00$"]},
    "Telegram": {"options": ["رقم أمريكي - 2.00$"]},
    "Instagram": {"subs": ["متابعين", "لايكات", "مشاهدات"]},
    "Facebook": {"subs": ["مشاهدات", "لايكات", "ريأكشن ستوري"]}
}

def send_telegram(message):
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        requests.post(url, json={"chat_id": TELEGRAM_CHAT_ID, "text": message})
    except:
        pass

def main(page: ft.Page):
    page.title = "بلاك ستور"
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = "#0A0A0A"
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.padding = 20
    page.scroll = ft.ScrollMode.AUTO
    
    balance = 150.0
    balance_text = ft.Text(f"💰 ${balance:.2f}", color="#00FF66", size=20, weight="bold")
    
    def toggle_drawer(e):
        page.drawer.open()
    
    page.appbar = ft.AppBar(
        leading=ft.IconButton(ft.icons.MENU, on_click=toggle_drawer, icon_color="#00FF66"),
        title=ft.Text("بلاك ستور", color="#FFFFFF", weight="bold"),
        bgcolor="#141414",
        center_title=True,
        actions=[balance_text]
    )
    
    page.drawer = ft.NavigationDrawer(
        controls=[
            ft.Container(height=20),
            ft.Container(content=ft.Text("👤", size=40), alignment=ft.alignment.center),
            ft.Container(content=ft.Text("test@example.com", color="#888888"), alignment=ft.alignment.center),
            ft.Divider(color="#333333"),
            ft.ListTile(leading=ft.Icon(ft.icons.ACCOUNT_BALANCE_WALLET), title=ft.Text("حسابي")),
            ft.ListTile(leading=ft.Icon(ft.icons.DARK_MODE), title=ft.Text("المظهر")),
            ft.ListTile(leading=ft.Icon(ft.icons.PAYMENT), title=ft.Text("طرق الدفع")),
            ft.ListTile(leading=ft.Icon(ft.icons.ADD), title=ft.Text("إضافة حساب")),
            ft.Divider(color="#333333"),
            ft.ListTile(leading=ft.Icon(ft.icons.LOGOUT, color="#FF4444"), title=ft.Text("تسجيل الخروج")),
        ],
        bgcolor="#1A1A1A"
    )
    
    def open_service(service):
        if service in ["WhatsApp", "Telegram"]:
            send_telegram(f"📱 طلب رقم {service}\n👤 test@example.com\n💵 2.00$")
            page.snack_bar = ft.SnackBar(ft.Text("✅ تم إرسال طلبك!"))
            page.snack_bar.open = True
            page.update()
            return
        
        if service in ["Instagram", "Facebook"]:
            subs = SERVICES[service]["subs"]
            content = ft.Column([
                ft.Text(f"📸 {service}", size=20, weight="bold", color="#00FF66"),
                *[ft.ElevatedButton(sub, on_click=lambda e, s=service, sub=sub: send_telegram(f"📦 طلب جديد: {s} - {sub}\n👤 test@example.com")) for sub in subs]
            ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
            dialog = ft.AlertDialog(title=ft.Text(f"{service}"), content=content)
            page.dialog = dialog
            dialog.open = True
            page.update()
            return
        
        options = SERVICES[service]["options"]
        content = ft.Column([
            ft.Text(f"🛒 {service}", size=20, weight="bold", color="#00FF66"),
            *[ft.ElevatedButton(opt, on_click=lambda e, opt=opt: send_telegram(f"📦 طلب جديد: {service}\n👤 test@example.com\n📌 {opt}")) for opt in options]
        ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
        dialog = ft.AlertDialog(title=ft.Text(f"{service}"), content=content)
        page.dialog = dialog
        dialog.open = True
        page.update()
    
    sections = [
        ("🎮 الألعاب", ["PUBG", "Free Fire", "Jawaker"]),
        ("💬 التطبيقات", ["Yaahlan", "imo", "Soulchill"]),
        ("⚡ حسابات جاهزة", ["CapCut", "ChatGPT", "PicsArt"]),
        ("📞 أرقام وهمية", ["WhatsApp", "Telegram"]),
        ("📸 السوشيال ميديا", ["Instagram", "Facebook"])
    ]
    
    for title, items in sections:
        page.add(ft.Text(title, size=18, weight="bold", color="#FFFFFF"))
        
        # ✅ كود صحيح بدون bgcolor داخل Row
        row = ft.Row(
            controls=[
                ft.ElevatedButton(
                    item,
                    on_click=lambda e, s=item: open_service(s),
                    bgcolor="#00FF66",
                    color="#000000",
                    style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=8))
                ) for item in items
            ],
            spacing=10,
            wrap=True,
        )
        page.add(row)
        page.add(ft.Divider(color="#333333"))
    
    page.add(ft.Row([
        ft.IconButton(ft.icons.HOME, icon_color="#00FF66"),
        ft.IconButton(ft.icons.ACCOUNT_BALANCE_WALLET, icon_color="#888888"),
        ft.IconButton(ft.icons.HISTORY, icon_color="#888888"),
        ft.IconButton(ft.icons.CREDIT_CARD, icon_color="#888888"),
        ft.IconButton(ft.icons.FAVORITE, icon_color="#888888"),
    ], alignment=ft.MainAxisAlignment.SPACE_AROUND))

ft.app(target=main)